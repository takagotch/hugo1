+++
banner = ""
categories = []
date = "2017-05-20T12:00:23+02:00"
description = ""
images = []
menu = ""
tags = []
title = "Using the gallery shortcode"
+++

This way you can easily include a gallery into your page. Copy the code below into your content file and enter the relative paths to your images.

<!--more-->


    {{</* gallery
        "/banners/placeholder.png"
        "/banners/placeholder.png"
        "/banners/placeholder.png"
    */>}}

<p></p>

{{< gallery "/banners/placeholder.png" "/banners/placeholder.png" "/banners/placeholder.png" >}}
