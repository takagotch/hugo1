---
title: "Redmi Watch"
date: 2019-10-17T11:22:16+06:00
image: "images/showcase/showcase-5.png"
images: 
  - "images/showcase/showcase-5.png"
  - "images/showcase/showcase-2.png"
  - "images/showcase/showcase-3.png"
  - "images/showcase/showcase-4.png"

# meta description
description : "this is meta description"

# product Price
price: "30.00"
discount_price: "25.00"

# product variation
colors : ["black","white","gray"]
sizes : ["small","medium","large"]

draft: false
---

Apple Watch is a line of smartwatches produced by Apple Inc. It incorporates fitness tracking and health-oriented capabilities with integration with iOS and other Apple products and services.
