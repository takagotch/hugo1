---
title: "FAQ"
date: 2019-10-17T11:22:16+06:00
draft: false
description : "this is a meta description"
---

### Frequently Asked Questions

Below FAQ are some common concerns of our clients before purchasing the <br> theme, if you have other questions, please just send it to demo@email.com