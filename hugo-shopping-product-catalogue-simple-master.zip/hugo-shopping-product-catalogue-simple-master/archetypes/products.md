{
    "title": "{{ replace .Name "-" " " | title }}",
    "date": "{{ .Date }}",
    "tags": [],
    "categories": [],
    "images": [],
    "thumbnailImage": "",
    "actualPrice": "",
    "comparePrice": "",
    "inStock": true,
    "options": {},
    "variants": []
}

**Insert Product description here****