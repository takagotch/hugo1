{
    "title": "Industrial Mesh Cage Wall Light Metal Mesh Up",
    "date": "2018-05-10T20:00:43+05:30",
    "tags": ["Wall Light"],
    "categories": ["Wall Light"],
    "images": ["img/industrial-mesh-cage-wall-light-metal-mesh-up/1.png", "img/industrial-mesh-cage-wall-light-metal-mesh-up/2.jpg", "img/industrial-mesh-cage-wall-light-metal-mesh-up/3.jpg"],
    "thumbnailImage": "img/industrial-mesh-cage-wall-light-metal-mesh-up/thumbnail.png",
    "actualPrice": "₹ 4608.00",
    "comparePrice": "₹ 5000.00",
    "inStock": false,
    "options": {},
    "variants": []
}

This classic cage light is perfect to add class and character to your home decor. The cult Edison Bulbs will definitely set a welcoming mood to your home interiors.

Size: L-30 x H-34cms

Light Fitting: E27 x 2

Color: Black Iron Metal