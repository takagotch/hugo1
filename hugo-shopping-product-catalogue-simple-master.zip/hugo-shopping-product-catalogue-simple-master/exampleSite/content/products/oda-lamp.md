{
    "title": "Oda Lamp",
    "date": "2018-05-12T13:50:55+05:30",
    "tags": ["Floor Light"],
    "categories": ["Floor Light"],
    "images": ["img/oda-lamp/1.jpg", "img/oda-lamp/2.jpg"],
    "thumbnailImage": "img/oda-lamp/thumbnail.jpg",
    "actualPrice": "₹ 12,960.00",
    "comparePrice": "₹ 25,920.00",
    "inStock": false,
    "options": {},
    "variants": []
}

Oda is a floor lamp made from a handblown tinted glass barrel balancing on a simple and elegant metal structure.

Material: Glass and wrought iron

Color: Smokey Grey

Dimensions: Glass portion: Dia- 36cm x H-45cm

Stand: L27cm x B27cm x H 107cm