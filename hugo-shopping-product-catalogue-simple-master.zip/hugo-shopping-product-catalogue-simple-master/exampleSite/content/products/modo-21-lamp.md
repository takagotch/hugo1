{
    "title": "Modo 21 Lamp",
    "date": "2018-05-12T15:54:25+05:30",
    "tags": ["chandeliers"],
    "categories": ["chandeliers"],
    "images": ["img/modo-21-lamp/1.jpg", "img/modo-21-lamp/2.jpg", "img/modo-21-lamp/2.jpg"],
    "thumbnailImage": "img/modo-21-lamp/thumbnail.jpg",
    "actualPrice": "₹ 85,000.00",
    "comparePrice": null,
    "inStock": true,
    "options": {},
    "variants": []
}

A mid-century modern chandelier which in inspired by the hub and spoke design. It has a modern take on a retro industrial style of lighting. The incandescent bulbs in the smoky glass globes glow beautifully when turned on. This chandelier offers warm ambient lighting and will effortless enhance your home decor. It is a luxury lighting fixture for your living room or dining room. Buy Luxury Chandeliers Online in India at best prices. Free Shipping.

Total Fixture Dimensions (in inches): D1235xH81cm

Material: Metal & Glass

Colour: Black & Grey

Bulb Holder: E14