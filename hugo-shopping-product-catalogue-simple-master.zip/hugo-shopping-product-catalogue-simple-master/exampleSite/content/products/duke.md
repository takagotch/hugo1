{
    "title": "Duke",
    "date": "2018-05-12T15:48:00+05:30",
    "tags": ["Floor Light"],
    "categories": ["Floor Light"],
    "images": ["img/duke/1.jpg", "img/duke/2.jpg", "img/duke/3.jpg"],
    "thumbnailImage": "img/duke/thumbnail.jpg",
    "actualPrice": "₹ 87,341.00",
    "comparePrice": null,
    "inStock": true,
    "options": {},
    "variants": []
}

Total Fixture Dimensions (in inches): 51x51x63

Material: Aluminium

Colour: Black Gold

Pack Content: 1 piece lamp with all parts included. Bulbs not included.

Bulb Recommended: E14 CFL, LED or Incandescent Bulb