{
    "title": "Void Pendant",
    "date": "2018-05-10T20:17:46+05:30",
    "tags": ["Pendant Light"],
    "categories": ["Pendant Light"],
    "images": ["img/void-pendant/1.jpg", "img/void-pendant/2.jpg", "img/void-pendant/3.jpg", "img/void-pendant/4.jpg"],
    "thumbnailImage": "img/void-pendant/thumbnail.jpg",
    "comparePrice": null,
    "actualPrice": "₹ 18,500.00",
    "inStock": true,
    "options": {},
    "variants": []
}

Inspired by vacuum flasks, Void is made from glass which is formed into a complex
double-walled shade. A small but powerful bulb deep inside the lamp creates a soft
but directional light beam, while the exterior is polished to a highly reflective
finish in Pendant and Surface light versions.