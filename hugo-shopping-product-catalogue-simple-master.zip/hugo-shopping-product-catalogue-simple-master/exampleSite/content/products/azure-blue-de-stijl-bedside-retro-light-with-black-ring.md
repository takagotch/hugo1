{
    "title": "Azure Blue De Stijl Inspired Bedside Retro Light",
    "date": "2018-05-10T08:02:34+05:30",
    "tags": ["Wall Light"],
    "categories": ["Wall Light"],
    "images" : ["img/azure-blue-de-stijl-bedside-retro-light-with-black-ring/1.jpg"],
    "thumbnailImage": "img/azure-blue-de-stijl-bedside-retro-light-with-black-ring/thumbnail.jpg",
    "actualPrice": null,
    "comparePrice": null,
    "inStock": null,
    "options": {
        "Type": ["With extension wire", "Without extension wire"]
    },
    "variants":  [
        {
            "optionCombination" : ["With extension wire"],
            "comparePrice": null,
            "actualPrice": "₹ 2917.00",
            "inStock": true
        },
        {
            "optionCombination" : ["Without extension wire"],
            "comparePrice": null,
            "actualPrice": "₹ 2000.00",
            "inStock": false
        }
    ]

}

The azure blue bedside modern retro lamp is functional at different levels and minimal in appearance. You can swivel it to your desired angle and pivot the light freely.

- Feature: 360 degrees swivel.
- Bulb: Not Included, Shop here
- Lighting part of the image: 40w T45 Edison Bulb
- Material: Iron
- Finish: Gloss Blue
- Diameter of the shade - 6 inches, Height of the shade - 4 inches
- Voltage - 110v-220v
- Powered by electricity
- Style - De Stijl
- Swivel Functionality: Yes
- Number of Lights - 1
- Power & Plug Description - Corded-electric
- Holder Type - E27
- On/Off Switch - No
- Warranty - 1-month warranty on manufacturing defects.