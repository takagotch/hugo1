{
    "title": "Retro Vintage Industrial Cage Pendant System",
    "date": "2018-05-10T20:11:38+05:30",
    "tags": ["Pendant Light"],
    "categories": ["Pendant Light"],
    "images": ["img/retro-vintage-industrial-cage-pendant-system/1.png", "img/retro-vintage-industrial-cage-pendant-system/2.png"],
    "thumbnailImage": "img/retro-vintage-industrial-cage-pendant-system/thumbnail.png",
    "actualPrice": "₹ 3,744.00",
    "comparePrice": null,
    "inStock": true,
    "options": {},
    "variants": []
}

Rustic look comes with industrial chic and luxe finish.This steampunk pendant system
is made of four wrought iron cage painted black and are complimented well with the
classic Edison filament Bulb.

100 YEARS AGO INDUSTRIAL WAS THE NORM, NOW IT IS A NOSTALGIC STYLE REMINISCING THE 
PAST.

Size: L-85 x W-10 x H-102cms

Light fitting: E27/E26 x 4

Material: Black iron metal + Brass aluminium lamp holders